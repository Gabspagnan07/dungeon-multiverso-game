
Dungeon Multiverso - Pacote v0.1 (GDevelop-ready)
===============================================

Como usar a demo web:
- Abra demo.html num navegador moderno (Chrome, Edge, Firefox).
- Clique em "Moeda (iniciar)" para decidir quem começa.
- Ajuste o número de dados e clique em "Rolar Dados". Cada dado gasta 1 de ENERGIA.
- Use Poção para curar. Ao derrotar monstros você ganha moedas e +1 Energia.

Como abrir o projeto no GDevelop (resumo):
1) Instale GDevelop: https://gdevelop.io/download
2) Crie novo projeto em branco (tela horizontal).
3) Importe os arquivos dentro da pasta 'assets' como recursos (Project manager -> Resources -> Add files).
4) Crie uma cena chamada CombatScene e adicione sprites e textos conforme o Event Sheet que eu te enviei.
5) Copie/cole os eventos do Event Sheet para o Event Sheet da cena.

Conteúdo:
- assets/ (placemarkers PNG)
- demo.html (versão web jogável)
- project.json (metadados)
- README.txt (instruções)
